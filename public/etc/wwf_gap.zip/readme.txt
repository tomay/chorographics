
README.txt	2.12.06
Tom Allnutt
WWF_GAP Tutorial and Training Materials, for use in conjunction with WWF_GAP.avx ArcView extension

Requires: ArcView 3.x and Spatial Analyst, Marxan (http://www.ecology.uq.edu.au/index.html?page=27710&pid=20497)

1. Unzip all files, while maintaining the original directory structure (typically the WinZip default).
2. Copy the extension (wwf_gap.avx) to the local ESRI ArcView extensions directory (typically C:\ESRI\AV_GIS30\ARCVIEW\EXT32).
3. Double-click the project titled "WWF_gap_tutorial.apr".
4. From here, follow instructions in the document titled "WWF_GAP tutorial.pdf".